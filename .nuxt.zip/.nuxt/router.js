import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _ebbf757a = () => interopDefault(import('../pages/admin/index.vue' /* webpackChunkName: "pages/admin/index" */))
const _9b0b28f8 = () => interopDefault(import('../pages/blog/index.vue' /* webpackChunkName: "pages/blog/index" */))
const _67fe96e1 = () => interopDefault(import('../pages/admin/account/index.vue' /* webpackChunkName: "pages/admin/account/index" */))
const _361f3104 = () => interopDefault(import('../pages/admin/blog/index.vue' /* webpackChunkName: "pages/admin/blog/index" */))
const _6a1ad048 = () => interopDefault(import('../pages/admin/dashboard/index.vue' /* webpackChunkName: "pages/admin/dashboard/index" */))
const _74f7435d = () => interopDefault(import('../pages/admin/login/index.vue' /* webpackChunkName: "pages/admin/login/index" */))
const _7a398b44 = () => interopDefault(import('../pages/admin/setting/index.vue' /* webpackChunkName: "pages/admin/setting/index" */))
const _8bc3f0aa = () => interopDefault(import('../pages/blog/article/index.vue' /* webpackChunkName: "pages/blog/article/index" */))
const _b288ff2e = () => interopDefault(import('../pages/blog/search/index.vue' /* webpackChunkName: "pages/blog/search/index" */))
const _25654d2b = () => interopDefault(import('../pages/admin/blog/article/index.vue' /* webpackChunkName: "pages/admin/blog/article/index" */))
const _6094908e = () => interopDefault(import('../pages/admin/blog/catalog/index.vue' /* webpackChunkName: "pages/admin/blog/catalog/index" */))
const _4b6b0158 = () => interopDefault(import('../pages/admin/blog/comment/index.vue' /* webpackChunkName: "pages/admin/blog/comment/index" */))
const _2417146e = () => interopDefault(import('../pages/admin/blog/editor/index.vue' /* webpackChunkName: "pages/admin/blog/editor/index" */))
const _2e592120 = () => interopDefault(import('../pages/admin/setting/menu/index.vue' /* webpackChunkName: "pages/admin/setting/menu/index" */))
const _5062d4c9 = () => interopDefault(import('../pages/admin/setting/user.vue' /* webpackChunkName: "pages/admin/setting/user" */))
const _7094f84e = () => interopDefault(import('../pages/admin/task/list.vue' /* webpackChunkName: "pages/admin/task/list" */))
const _471933be = () => interopDefault(import('../pages/blog/search/search.vue' /* webpackChunkName: "pages/blog/search/search" */))
const _834e894a = () => interopDefault(import('../pages/blog/article/temp/comment.vue' /* webpackChunkName: "pages/blog/article/temp/comment" */))
const _a88a7ec2 = () => interopDefault(import('../pages/blog/article/temp/common.vue' /* webpackChunkName: "pages/blog/article/temp/common" */))
const _57638913 = () => interopDefault(import('../pages/blog/article/temp/menu.vue' /* webpackChunkName: "pages/blog/article/temp/menu" */))
const _0cf750b5 = () => interopDefault(import('../pages/blog/article/temp/special.vue' /* webpackChunkName: "pages/blog/article/temp/special" */))
const _736173d4 = () => interopDefault(import('../pages/blog/article/temp/title.vue' /* webpackChunkName: "pages/blog/article/temp/title" */))
const _43600e5a = () => interopDefault(import('../pages/blog/article/_id.vue' /* webpackChunkName: "pages/blog/article/_id" */))
const _f96b0a7a = () => interopDefault(import('../pages/index.vue' /* webpackChunkName: "pages/index" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/admin",
    component: _ebbf757a,
    name: "admin"
  }, {
    path: "/blog",
    component: _9b0b28f8,
    name: "blog"
  }, {
    path: "/admin/account",
    component: _67fe96e1,
    name: "admin-account"
  }, {
    path: "/admin/blog",
    component: _361f3104,
    name: "admin-blog"
  }, {
    path: "/admin/dashboard",
    component: _6a1ad048,
    name: "admin-dashboard"
  }, {
    path: "/admin/login",
    component: _74f7435d,
    name: "admin-login"
  }, {
    path: "/admin/setting",
    component: _7a398b44,
    name: "admin-setting"
  }, {
    path: "/blog/article",
    component: _8bc3f0aa,
    name: "blog-article"
  }, {
    path: "/blog/search",
    component: _b288ff2e,
    name: "blog-search"
  }, {
    path: "/admin/blog/article",
    component: _25654d2b,
    name: "admin-blog-article"
  }, {
    path: "/admin/blog/catalog",
    component: _6094908e,
    name: "admin-blog-catalog"
  }, {
    path: "/admin/blog/comment",
    component: _4b6b0158,
    name: "admin-blog-comment"
  }, {
    path: "/admin/blog/editor",
    component: _2417146e,
    name: "admin-blog-editor"
  }, {
    path: "/admin/setting/menu",
    component: _2e592120,
    name: "admin-setting-menu"
  }, {
    path: "/admin/setting/user",
    component: _5062d4c9,
    name: "admin-setting-user"
  }, {
    path: "/admin/task/list",
    component: _7094f84e,
    name: "admin-task-list"
  }, {
    path: "/blog/search/search",
    component: _471933be,
    name: "blog-search-search"
  }, {
    path: "/blog/article/temp/comment",
    component: _834e894a,
    name: "blog-article-temp-comment"
  }, {
    path: "/blog/article/temp/common",
    component: _a88a7ec2,
    name: "blog-article-temp-common"
  }, {
    path: "/blog/article/temp/menu",
    component: _57638913,
    name: "blog-article-temp-menu"
  }, {
    path: "/blog/article/temp/special",
    component: _0cf750b5,
    name: "blog-article-temp-special"
  }, {
    path: "/blog/article/temp/title",
    component: _736173d4,
    name: "blog-article-temp-title"
  }, {
    path: "/blog/article/:id",
    component: _43600e5a,
    name: "blog-article-id"
  }, {
    path: "/",
    component: _f96b0a7a,
    name: "index"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
